"""Example Solara app as python packages"""
__title__ = "Solara example app"
__version__ = "0.0.1"
