"""# FileDownload

"""
import solara
from solara.website.utils import apidoc

from . import NoPage

Page = NoPage
title = "FileDownload"


__doc__ += apidoc(solara.FileDownload.f)  # type: ignore
