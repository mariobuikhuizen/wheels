"""
# AppBarTitle

"""
import solara
import solara.lab
from solara.website.utils import apidoc

from . import NoPage

title = "AppBarTitle"

Page = NoPage


__doc__ += apidoc(solara.AppBarTitle.f)  # type: ignore
