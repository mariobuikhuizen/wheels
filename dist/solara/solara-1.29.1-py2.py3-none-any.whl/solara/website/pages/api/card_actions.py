"""
# CardActions

"""
import solara
import solara.lab
from solara.website.utils import apidoc

from . import NoPage

title = "CardActions"

Page = NoPage


__doc__ += apidoc(solara.CardActions.f)  # type: ignore
