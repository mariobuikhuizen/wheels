"""Demonstrates very basic usage of Solara."""
redirect = None
