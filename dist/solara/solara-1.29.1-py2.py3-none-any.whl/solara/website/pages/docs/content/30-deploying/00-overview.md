# Deploying a solara app

A Solara app can be [self hosted](/docs/deploying/self-hosted) or [cloud hosted](/docs/deploying/cloud-hosted).
