# Fundamentals

If you want to dive deeper into Solara, this section is for you. We will cover the following topics:

  * [Components](/docs/fundamentals/components)
  * Hooks (soon)
  * [State management](/docs/fundamentals/state-management)
